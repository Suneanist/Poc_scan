import requests
import threading
from urllib.parse import urljoin
from concurrent.futures import ThreadPoolExecutor
from PyQt5.QtCore import QThread, pyqtSignal


class DirectoryBruteForcer:
    #初始化参数
        def __init__(
                self,
                target_url: str,
                wordlist_path: str,
                headers: dict = None,
                valid_status_codes: list = None,
                timeout: int = 5,
                allow_redirects: bool = False,
                http_method: str = "GET",
                max_threads: int = 10
        ):
            self.target_url = target_url.rstrip('/')
            self.wordlist_path = wordlist_path
            self.headers = headers or {"User-Agent": "Mozilla/5.0"}
            self.valid_status_codes = valid_status_codes or [200] #有效状态码，默认200
            self.timeout = timeout
            self.allow_redirects = allow_redirects  #是否跟进重定向
            self.http_method = http_method.upper()
            self.max_threads = max_threads   #最大线程
            self.found_paths = []
            self.lock = threading.Lock()

        def load_wordlist(self) -> list:
            try:
                with open(self.wordlist_path, 'r', encoding='utf-8') as f:
                    return [line.strip() for line in f if line.strip()]
            except Exception as e:
                print(f"[!] 加载字典文件失败: {e}")
                return []

        def check_path(self, path: str):
            target = urljoin(self.target_url + '/', path)
            try:
                response = requests.request(
                    method=self.http_method,
                    url=target,
                    headers=self.headers,
                    timeout=self.timeout,
                    allow_redirects=self.allow_redirects
                )

                if response.status_code in self.valid_status_codes:
                    with self.lock:
                        self.found_paths.append((
                            response.status_code,
                            len(response.content),
                            target
                        ))
                        print(f"[+] Found {target} ({response.status_code})")

            except requests.RequestException as e:
                with self.lock:
                    print(f"[!] 请求失败: {target} - {str(e)}")

        def start_bruteforce(self):  #开始爆破
            wordlist = self.load_wordlist()
            if not wordlist:
                return

            print(f"[*] 开始爆破 {self.target_url}")
            print(f"[*] 加载 {len(wordlist)} 条路径")

            with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
                executor.map(self.check_path, wordlist)

            print("\n[+] 发现的有效路径:")
            for code, size, url in sorted(self.found_paths):
                print(f"- {code:3} | {size:6} bytes | {url}")

# 增强版调用示例
if __name__ == "__main__":
    # 配置参数（根据实际需求修改以下参数）
    config = {
        "target_url": "http://testphp.vulnweb.com",  # 替换为实际目标URL
        "wordlist_path": "common_paths.txt",  # 指定字典文件路径
        "valid_status_codes": [200, 301, 302, 403, 500],  # 视为有效的状态码
        "http_method": "GET",  # 请求方法
        "max_threads": 30,  # 并发线程数
        "timeout": 5,  # 请求超时时间
        "headers": {  # 自定义请求头
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) DirBuster/1.0",
            "Accept-Language": "en-US,en;q=0.9"
        }
    }

    try:
        # 实例化爆破器对象
        bruter = DirectoryBruteForcer(**config)

        # 开始执行目录爆破
        print("[*] 初始化目录爆破器...")
        bruter.start_bruteforce()

        # 添加后续处理逻辑（例如保存结果到文件）
        if bruter.found_paths:
            with open("scan_results.txt", "w") as f:
                f.write("扫描结果:\n")
                for code, size, url in bruter.found_paths:
                    f.write(f"{code} | {size} bytes | {url}\n")
            print("[+] 结果已保存到 scan_results.txt")

    except KeyboardInterrupt:
        print("\n[!] 用户中断扫描")
    except Exception as e:
        print(f"[!] 发生未预期错误: {str(e)}")

    def start_bruteforce(self):
        wordlist = self.load_wordlist()
        if not wordlist:
            return

        with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
            executor.map(self.check_path, wordlist)

class ScanThread(QThread):
    update_result = pyqtSignal(dict)  # 结果更新信号（类型字典）
    scan_finished = pyqtSignal()  # 扫描完成信号

    def __init__(self, target, dict_path, threads):
        super().__init__()
        self.target = target
        self.dict_path = dict_path
        self.threads = int(threads)
        self._is_running = True  # 控制线程运行的标志位

    def run(self):
        """线程主逻辑"""
        try:
            self.bruter = DirectoryBruteForcer(
                target_url=self.target,
                wordlist_path=self.dict_path,
                max_threads=self.threads
            )

            # 重写检查路径方法以实现实时回调
            original_check_path = self.bruter.check_path

            def wrapped_check_path(path):
                if not self._is_running:
                    return
                original_check_path(path)
                target = urljoin(self.bruter.target_url + '/', path)
                self.update_result.emit({  # 发射信号
                    "type": "目录爆破",
                    "target": target,
                    "status": "进行中",
                    "found": "检测中..."
                })

            self.bruter.check_path = wrapped_check_path

            # 开始爆破
            self.bruter.start_bruteforce()

        except Exception as e:
            self.update_result.emit({
                "type": "错误",
                "target": self.target,
                "status": "失败",
                "found": str(e)
            })
        finally:
            self.scan_finished.emit()

    def stop(self):
        """停止扫描"""
        self._is_running = False
        if self.bruter:
            self.bruter.found_paths = []  # 清空结果
