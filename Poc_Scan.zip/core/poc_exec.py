import importlib.util
import sys
from PyQt5.QtCore import QObject, pyqtSignal, QThread


class POCScanThread(QThread):

    def __init__(self, scanner):
        super().__init__()
        self.scanner = scanner

    def run(self):
        self.scanner.run()

    def stop(self):
        self.scanner.stop()

class POCScanner(QObject):
    update_result = pyqtSignal(dict)
    finished = pyqtSignal()

    def __init__(self, target, poc_paths):
        super().__init__()
        self.target = target
        self.poc_paths = poc_paths
        self._running = True

    def run(self):
        """执行所有POC验证"""
        for poc_path in self.poc_paths:
            if not self._running:
                break

            try:
                # 动态加载POC模块
                spec = importlib.util.spec_from_file_location("poc_module", poc_path)
                poc_module = importlib.util.module_from_spec(spec)
                sys.modules["poc_module"] = poc_module
                spec.loader.exec_module(poc_module)

                # 调用验证函数
                if hasattr(poc_module, 'verify'):
                    result = poc_module.verify(self.target)
                    self.handle_result(poc_path, result)
                else:
                    self.update_result.emit({
                        'type': 'POC',
                        'target': self.target,
                        'status': '错误',
                        'found': f"{poc_path} 缺少verify函数"
                    })
            except Exception as e:
                self.update_result.emit({
                    'type': 'POC',
                    'target': self.target,
                    'status': '异常',
                    'found': f"{poc_path} 执行失败: {str(e)}"
                })

        self.finished.emit()

    def handle_result(self, poc_path, result):
        """处理验证结果"""
        if result.get('vulnerable', False):
            self.update_result.emit({
                'type': 'POC',
                'target': self.target,
                'status': '成功',
                'found': f"{poc_path.split('/')[-1]} 发现漏洞: {result['details']}"
            })
        else:
            self.update_result.emit({
                'type': 'POC',
                'target': self.target,
                'status': '安全',
                'found': f"{poc_path.split('/')[-1]} 未发现漏洞"
            })

    def stop(self):
        """停止扫描"""
        self._running = False

