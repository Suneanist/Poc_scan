from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
                             QRadioButton, QPushButton, QTextEdit,
                             QMessageBox, QButtonGroup, QFileDialog)
import json
import os


class CustomPOCWindow(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("自定义POC")
        self.setGeometry(400, 400, 450, 520)  # 增加窗口高度
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # 漏洞类型选择
        vuln_layout = QHBoxLayout()
        self.vuln_group = QButtonGroup()
        self.sql_radio = QRadioButton("SQL注入")
        self.rce_radio = QRadioButton("RCE")
        self.xss_radio = QRadioButton("XSS")
        self.other_radio = QRadioButton("其他")
        self.sql_radio.setChecked(True)
        vuln_layout.addWidget(QLabel("漏洞类型:"))
        vuln_layout.addWidget(self.sql_radio)
        vuln_layout.addWidget(self.rce_radio)
        vuln_layout.addWidget(self.xss_radio)
        vuln_layout.addWidget(self.other_radio)
        layout.addLayout(vuln_layout)

        # 目标参数配置
        target_layout = QHBoxLayout()
        target_layout.addWidget(QLabel("目标参数:"))
        self.target_param = QLineEdit()
        self.target_param.setPlaceholderText("输入目标参数名（如: url）")
        target_layout.addWidget(self.target_param)
        layout.addLayout(target_layout)

        # 请求方法选择
        method_layout = QHBoxLayout()
        self.method_get = QRadioButton("GET")
        self.method_post = QRadioButton("POST")
        self.method_get.setChecked(True)
        method_layout.addWidget(QLabel("请求方法:"))
        method_layout.addWidget(self.method_get)
        method_layout.addWidget(self.method_post)
        layout.addLayout(method_layout)

        # 请求路径配置
        path_layout = QHBoxLayout()
        path_layout.addWidget(QLabel("请求路径:"))
        self.request_path = QLineEdit()
        self.request_path.setPlaceholderText("/vulnerable-endpoint")
        path_layout.addWidget(self.request_path)
        layout.addLayout(path_layout)

        # POST参数类型选择
        self.post_type_group = QButtonGroup()
        post_type_layout = QHBoxLayout()
        self.json_radio = QRadioButton("JSON")
        self.form_radio = QRadioButton("表单数据")
        self.json_radio.setChecked(True)
        self.post_type_group.addButton(self.json_radio)
        self.post_type_group.addButton(self.form_radio)
        post_type_layout.addWidget(QLabel("参数类型:"))
        post_type_layout.addWidget(self.json_radio)
        post_type_layout.addWidget(self.form_radio)
        layout.addLayout(post_type_layout)

        # POST参数输入
        self.post_params_label = QLabel("POST参数:")
        self.post_params = QTextEdit()
        self.post_params.setMaximumHeight(100)
        self.post_params.setPlaceholderText(
            'JSON示例：{"key": "value"}\n'
            '表单示例：key1=value1&key2=value2\n'
            '或多行键值对：\nkey1=value1\nkey2=value2'
        )
        self.post_params.setVisible(False)
        layout.addWidget(self.post_params_label)
        layout.addWidget(self.post_params)

        # 生成按钮
        self.generate_btn = QPushButton("生成POC脚本")
        self.generate_btn.setStyleSheet("background-color: #673AB7; color: white;")
        self.generate_btn.clicked.connect(self.generate_poc)
        layout.addWidget(self.generate_btn)

        # 事件绑定
        self.method_post.toggled.connect(self.toggle_post_params)
        self.setLayout(layout)

    def toggle_post_params(self, checked):
        """切换POST参数可见性"""
        self.post_params.setVisible(checked)
        self.post_params_label.setVisible(checked)

    def parse_post_data(self, raw_data):
        """解析POST参数"""
        try:
            raw_data = raw_data.strip()
            if not raw_data:
                return "{}", None  # 处理空输入

            if self.json_radio.isChecked():
                parsed = json.loads(raw_data)
                return repr(parsed), None
            else:
                if "\n" in raw_data:
                    params = dict(line.strip().split("=", 1)
                                  for line in raw_data.split("\n")
                                  if "=" in line)
                else:
                    params = dict(pair.split("=", 1)
                                  for pair in raw_data.split("&")
                                  if "=" in pair)
                return repr(params), None
        except Exception as e:
            return None, str(e)

    def generate_poc(self):
        """生成POC模板脚本"""
        target_param = self.target_param.text().strip()
        request_path = self.request_path.text().strip()
        method = "POST" if self.method_post.isChecked() else "GET"

        # 输入验证
        if not all([target_param, request_path]):
            QMessageBox.warning(self, "错误", "请填写所有必填项！")
            return

        # POST参数处理
        post_data = None
        if method == "POST":
            raw_data = self.post_params.toPlainText().strip()
            if not raw_data:
                QMessageBox.warning(self, "错误", "POST方法需要填写参数！")
                return

            parsed_data, error = self.parse_post_data(raw_data)
            if error:
                QMessageBox.warning(
                    self, "参数错误",
                    f"参数解析失败：{error}\n"
                    f"JSON格式示例：{{\"key\": \"value\"}}\n"
                    f"表单格式示例：key1=value1&key2=value2"
                )
                return
            post_data = parsed_data

        # 获取漏洞类型
        vuln_type = "SQL" if self.sql_radio.isChecked() else \
            "RCE" if self.rce_radio.isChecked() else \
                "XSS" if self.xss_radio.isChecked() else "OTHER"

        # 构建不同漏洞的检测逻辑
        detection_logic = ""
        if vuln_type == "SQL":
            detection_logic = '''
        if response.status_code == 200:
            # SQL注入检测逻辑
            if "sql" in response.text.lower():
                result.update({
                    'vulnerable': True,
                    'details': "SQL注入漏洞验证成功",
                    'response': response.text[:500]
                })
            else:
                result['details'] = "未检测到SQL注入特征"'''
        elif vuln_type == "RCE":
            detection_logic = '''
        # RCE检测逻辑（示例）
        if response.status_code == 200 and "command executed" in response.text:
            result.update({
                'vulnerable': True,
                'details': "RCE漏洞验证成功",
                'response': response.text[:500]
            })'''
        elif vuln_type == "XSS":
            detection_logic = '''
        # XSS检测逻辑（示例）
        if response.status_code == 200 and "<script>alert" in response.text:
            result.update({
                'vulnerable': True,
                'details': "XSS漏洞验证成功",
                'response': response.text[:500]
            })'''
        else:  # 其他类型
            detection_logic = '''
        # 自定义检测逻辑
        # 在此处添加您的验证条件
        if response.status_code == 200:
            result.update({
                'vulnerable': True,  # 根据实际情况修改
                'details': "漏洞验证成功",
                'response': response.text[:500]
            })'''

        # 构建POC模板
        poc_code = f'''import requests

def verify(target):
    result = {{'vulnerable': False}}
    try:
        url = target.rstrip('/') + "{request_path}"
        headers = {{"User-Agent": "Mozilla/5.0"}}
        method = "{method}"

        if method == "GET":
            response = requests.get(url, headers=headers)
        else:
            data = {post_data if post_data else {{}} }
            {'response = requests.post(url, json=data, headers=headers)'
        if self.json_radio.isChecked()
        else 'response = requests.post(url, data=data, headers=headers)'}

        {detection_logic}
        return result
    except Exception as e:
        result['error'] = str(e)
        return result
'''

        # 弹出目录选择对话框
        save_dir = QFileDialog.getExistingDirectory(
            self,
            "选择保存目录",
            os.path.expanduser("~")  # 默认从用户目录开始
        )
        if not save_dir:  # 用户取消选择
            return

        # 保存文件
        save_path = os.path.join(save_dir, "custom_poc.py")
        try:
            with open(save_path, "w", encoding="utf-8") as f:
                f.write(poc_code)
            QMessageBox.information(
                self,
                "保存成功",
                f"POC脚本已保存至：\n{save_path}"
            )
        except PermissionError:
            QMessageBox.critical(
                self,
                "错误",
                "无权限写入目标目录！"
            )
        except Exception as e:
            QMessageBox.critical(
                self,
                "错误",
                f"保存失败：{str(e)}"
            )