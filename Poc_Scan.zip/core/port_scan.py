import queue
import socket
import threading
import time
from PyQt5.QtCore import QThread, pyqtSignal, Qt
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLineEdit,
                             QLabel, QPushButton, QTextEdit, QProgressBar,
                             QMessageBox, QFileDialog)

class PortScannerWindow(QWidget):
    def __init__(self, target):
        super().__init__()
        self.target = target
        self.open_ports = []
        self.scan_thread = None
        self.init_ui()
        self.setWindowTitle(f"端口扫描 - {target}")
        self.setGeometry(400, 400, 500, 400)
        self.setWindowFlag(Qt.WindowStaysOnTopHint)  # 添加窗口置顶属性

    def init_ui(self):
        layout = QVBoxLayout()
        # 端口范围输入
        port_range_layout = QHBoxLayout()
        self.start_port = QLineEdit("1")
        self.end_port = QLineEdit("10000")
        port_range_layout.addWidget(QLabel("起始端口:"))
        port_range_layout.addWidget(self.start_port)
        port_range_layout.addWidget(QLabel("结束端口:"))
        port_range_layout.addWidget(self.end_port)

        # 控制按钮
        btn_layout = QHBoxLayout()
        self.start_btn = QPushButton("开始扫描")
        self.start_btn.clicked.connect(self.start_scan)
        self.stop_btn = QPushButton("停止扫描")
        self.stop_btn.clicked.connect(self.stop_scan)
        self.save_btn = QPushButton("保存结果")
        self.save_btn.clicked.connect(self.save_results)
        btn_layout.addWidget(self.start_btn)
        btn_layout.addWidget(self.stop_btn)
        btn_layout.addWidget(self.save_btn)

        # 结果展示
        self.result_area = QTextEdit()
        self.result_area.setReadOnly(True)
        self.progress_bar = QProgressBar()

        layout.addLayout(port_range_layout)
        layout.addLayout(btn_layout)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.result_area)
        self.setLayout(layout)

        self.stop_btn.setEnabled(False)
        self.save_btn.setEnabled(False)

    def start_scan(self):
        """启动端口扫描"""
        try:
            start = int(self.start_port.text())
            end = int(self.end_port.text())
            if not (0 < start <= end <= 65535):
                raise ValueError
        except:
            QMessageBox.critical(self, "错误", "端口范围:1-65535")
            return

        self.open_ports = []
        self.result_area.clear()
        self.progress_bar.setRange(0, end - start + 1)  # 修正进度计算
        self.progress_bar.setValue(0)

        self.scan_thread = PortScanThread(
            target=self.target,
            start_port=start,
            end_port=end
        )
        # 新增错误信号连接
        self.scan_thread.error_occurred.connect(self.show_error)
        self.scan_thread.port_scanned.connect(self.update_progress)
        self.scan_thread.open_port_found.connect(self.add_open_port)
        self.scan_thread.finished.connect(self.on_scan_finished)

        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.scan_thread.start()

    def stop_scan(self):
        """安全停止扫描"""
        if self.scan_thread and self.scan_thread.isRunning():
            self.scan_thread.safe_stop()  # 使用安全停止方法
            self.result_area.append("\n正在停止扫描...")
            self.stop_btn.setEnabled(False)

    def show_error(self, msg):
        """显示错误信息"""
        self.result_area.append(f"<font color='red'>[错误] {msg}</font>")

    def save_results(self):
        """保存扫描结果到文件"""
        if not self.open_ports:
            QMessageBox.warning(self, "警告", "没有可保存的结果！")
            return

        file_path, _ = QFileDialog.getSaveFileName(
            self, "保存结果", "", "文本文件 (*.txt)"
        )
        if file_path:
            try:
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(f"目标: {self.target}\n")
                    f.write("开放的端口:\n")
                    for port in self.open_ports:
                        f.write(f"端口 {port}\n")
                QMessageBox.information(self, "成功", "结果已保存！")
            except Exception as e:
                QMessageBox.critical(self, "错误", f"保存失败: {str(e)}")

    def add_open_port(self, port):
        """新增开放端口到结果"""
        self.open_ports.append(port)
        self.result_area.append(f"发现开放端口: {port}")

    def update_progress(self, value):
        """更新进度条"""
        self.progress_bar.setValue(value)

    def on_scan_finished(self):
        """扫描完成处理"""
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.save_btn.setEnabled(bool(self.open_ports))
        self.result_area.append("\n扫描完成！")


class PortScanThread(QThread):
    port_scanned = pyqtSignal(int)
    open_port_found = pyqtSignal(int)
    error_occurred = pyqtSignal(str)

    def __init__(self, target, start_port, end_port, timeout=1.0, max_threads=100):  # 增加线程数参数
        super().__init__()
        self.target = target
        self.start_port = start_port
        self.end_port = end_port
        self.timeout = timeout  # 缩短超时时间
        self.max_threads = max_threads  # 最大并发线程数
        self._is_running = True
        self.lock = threading.Lock()  # 线程锁
        self.ports_queue = queue.Queue()  # 端口队列

    def run(self):
        try:
            # 初始化端口队列
            for port in range(self.start_port, self.end_port + 1):
                self.ports_queue.put(port)

            total_ports = self.end_port - self.start_port + 1
            threads = []

            # 创建线程池
            for _ in range(self.max_threads):
                thread = threading.Thread(target=self.scan_worker)
                thread.daemon = True
                thread.start()
                threads.append(thread)

            # 等待所有端口完成
            while not self.ports_queue.empty() and self._is_running:
                time.sleep(0.1)

            self.ports_queue.queue.clear()  # 清空队列

        except Exception as e:
            self.error_occurred.emit(f"扫描初始化失败: {str(e)}")

    def scan_worker(self):
        """工作线程方法"""
        while self._is_running and not self.ports_queue.empty():
            try:
                port = self.ports_queue.get_nowait()
            except queue.Empty:
                break

            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(self.timeout)
                    result = s.connect_ex((self.target, port))
                    if result == 0:
                        self.open_port_found.emit(port)

                with self.lock:  # 线程安全操作
                    self.port_scanned.emit(1)  # 每个端口完成+1

            except Exception as e:
                self.error_occurred.emit(f"端口 {port} 扫描错误: {str(e)}")
            finally:
                self.ports_queue.task_done()

    def safe_stop(self):
        """停止扫描"""
        self._is_running = False
        self.ports_queue.queue.clear()