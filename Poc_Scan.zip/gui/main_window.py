from PyQt5.QtCore import Qt
from core.dir_brute import ScanThread
from core.port_scan import PortScannerWindow
from core.poc_exec import POCScanner, POCScanThread
from core.poc_layout import CustomPOCWindow
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit,
    QFileDialog, QProgressBar, QCheckBox, QGroupBox, QMessageBox)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.init_ui()
        self.init_variables()
        self.setup_window()

    def init_variables(self):
        """初始化成员变量"""
        self.scanner = None
        self.selected_pocs = []
        self.selected_dict = None
        self.scan_thread = None  # 目录扫描线程
        self.poc_thread = None  # POC扫描线程

    def setup_window(self):
        """窗口基本设置"""
        self.setWindowTitle('POC_Scan')
        self.setGeometry(300, 300, 1000, 800)

    def init_ui(self):
        """初始化界面组件"""
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()

        # 目标输入区域
        target_group = QGroupBox("扫描目标配置")
        target_layout = QHBoxLayout()
        self.target_input = QLineEdit()
        self.target_input.setPlaceholderText("输入IP地址或域名,注意：目录扫描需要添加协议，端口扫描只需输入IP")
        target_layout.addWidget(QLabel("目标:"))
        target_layout.addWidget(self.target_input)
        target_group.setLayout(target_layout)

        # 端口扫描配置
        self.port_scan_btn = QPushButton("端口扫描")
        self.port_scan_btn.setStyleSheet("background-color: #2196F3; color: white;")
        (self.port_scan_btn.clicked.
         connect(self.open_port_scanner))
        target_layout.addWidget(self.port_scan_btn)

        # 目录爆破配置
        dir_scan_group = QGroupBox("目录爆破配置")
        dir_scan_layout = QHBoxLayout()
        self.enable_dir_scan = QCheckBox("启用目录爆破")

        # 字典选择组件
        dict_selector_layout = QVBoxLayout()
        self.dict_select_btn = QPushButton("选择字典文件")
        self.dict_select_btn.clicked.connect(self.select_dict)
        self.dict_path_label = QLabel("未选择字典")
        dict_selector_layout.addWidget(self.dict_select_btn)
        dict_selector_layout.addWidget(self.dict_path_label)

        # 线程数配置
        thread_layout = QHBoxLayout()
        thread_layout.addWidget(QLabel("并发线程:"))
        self.threads_input = QLineEdit("10")
        self.threads_input.setFixedWidth(50)
        thread_layout.addWidget(self.threads_input)

        # 组合布局
        dir_scan_layout.addWidget(self.enable_dir_scan)
        dir_scan_layout.addLayout(dict_selector_layout)
        dir_scan_layout.addLayout(thread_layout)
        dir_scan_group.setLayout(dir_scan_layout)

        # -------------------- 漏洞检测配置 --------------------
        poc_group = QGroupBox("漏洞检测配置")
        poc_layout = QHBoxLayout()
        self.poc_select_btn = QPushButton("选择POC脚本")
        self.poc_select_btn.clicked.connect(self.select_pocs)
        self.custom_poc_btn = QPushButton("自定义POC")  # 新增按钮
        self.custom_poc_btn.setStyleSheet("background-color: #9C27B0; color: white;")
        self.custom_poc_btn.clicked.connect(self.show_custom_poc_window)
        self.poc_status_label = QLabel("已选择0个POC")
        poc_layout.addWidget(QLabel("POC脚本:"))
        poc_layout.addWidget(self.poc_select_btn)
        poc_layout.addWidget(self.custom_poc_btn)  # 添加自定义按钮
        poc_layout.addWidget(self.poc_status_label)
        poc_group.setLayout(poc_layout)

        # -------------------- 控制按钮 --------------------
        ctrl_group = QGroupBox("扫描控制")
        ctrl_layout = QHBoxLayout()
        self.start_btn = QPushButton("开始扫描")
        self.start_btn.setStyleSheet("background-color: #4CAF50; color: white;")
        self.start_btn.clicked.connect(self.start_scan)
        self.stop_btn = QPushButton("停止扫描")
        self.stop_btn.setStyleSheet("background-color: #f44336; color: white;")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.stop_scan)
        # 新增重置按钮
        self.reset_btn = QPushButton("重置")
        self.reset_btn.setStyleSheet("background-color: #FF9800; color: white;")
        self.reset_btn.clicked.connect(self.reset_fields)
        ctrl_layout.addWidget(self.start_btn)
        ctrl_layout.addWidget(self.stop_btn)
        ctrl_layout.addWidget(self.reset_btn)
        ctrl_group.setLayout(ctrl_layout)

        # -------------------- 进度条 --------------------
        self.progress_bar = QProgressBar()
        self.progress_bar.setAlignment(Qt.AlignCenter)

        # -------------------- 结果展示 --------------------
        result_group = QGroupBox("扫描结果")
        result_layout = QVBoxLayout()
        self.result_display = QTextEdit()
        self.result_display.setReadOnly(True)
        self.result_display.setStyleSheet("font-family: Consolas; font-size: 12px;")
        result_layout.addWidget(self.result_display)
        result_group.setLayout(result_layout)

        # -------------------- 组合所有组件 --------------------
        main_layout.addWidget(target_group)
        main_layout.addWidget(dir_scan_group)
        main_layout.addWidget(poc_group)
        main_layout.addWidget(ctrl_group)
        main_layout.addWidget(self.progress_bar)
        main_layout.addWidget(result_group)
        main_widget.setLayout(main_layout)

    # ==================== 功能方法 ====================

    def reset_fields(self):
        """重置目标输入和扫描结果"""
        self.target_input.clear()
        self.result_display.clear()
        # 可选：重置其他组件状态
        # self.progress_bar.reset()

    def select_pocs(self):
        """选择POC脚本文件"""
        files, _ = QFileDialog.getOpenFileNames(
            self, "选择POC脚本", "pocs/", "Python文件 (*.py)"
        )
        if files:
            self.selected_pocs = files
            self.poc_status_label.setText(f"已选择{len(files)}个POC")

    def select_dict(self):
        """选择字典文件"""
        file, _ = QFileDialog.getOpenFileName(
            self, "选择字典文件", "", "文本文件 (*.txt)"
        )
        if file:
            self.selected_dict = file
            self.dict_path_label.setText(file.split('/')[-1])

    def open_port_scanner(self):
        """打开端口扫描窗口"""
        target = self.target_input.text().strip()
        if not target:
            QMessageBox.warning(self, "错误", "请先输入目标地址！")
            return
        self.port_window = PortScannerWindow(target)
        self.port_window.show()

    def start_scan(self):
        """启动扫描"""
        # 输入校验
        if not self.target_input.text().strip():
            QMessageBox.warning(self, "错误", "请输入目标地址！")
            return
        if self.enable_dir_scan.isChecked() and not self.selected_dict:
            QMessageBox.warning(self, "错误", "请选择字典文件！")
            return

        # 初始化目录扫描线程
        target = self.target_input.text().strip()
        if self.enable_dir_scan.isChecked():
            self.scan_thread = ScanThread(
                target=target,
                dict_path=self.selected_dict,
                threads=self.threads_input.text()
            )
            self.scan_thread.update_result.connect(self.update_results)
            self.scan_thread.scan_finished.connect(self.on_scan_finished)
            self.scan_thread.start()

        # 初始化POC扫描线程
        if self.selected_pocs:
            poc_scanner = POCScanner(target, self.selected_pocs)
            self.poc_thread = POCScanThread(poc_scanner)
            poc_scanner.update_result.connect(self.update_results)
            self.poc_thread.finished.connect(self.on_scan_finished)
            self.poc_thread.start()

        # 更新界面状态
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.progress_bar.setRange(0, 0)

    def stop_scan(self):
        """停止扫描"""
        # 停止目录扫描
        if self.scan_thread and self.scan_thread.isRunning():
            self.scan_thread.stop()
            self.scan_thread.terminate()

        # 停止POC扫描
        if self.poc_thread and self.poc_thread.isRunning():
            self.poc_thread.stop()
            self.poc_thread.terminate()

        # 重置界面
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)

    def on_scan_finished(self):
        """扫描完成处理"""
        # 检查所有线程是否都已完成
        dir_scan_finished = not (self.scan_thread and self.scan_thread.isRunning())
        poc_scan_finished = not (self.poc_thread and self.poc_thread.isRunning())

        if dir_scan_finished and poc_scan_finished:
            self.progress_bar.setRange(0, 100)
            self.progress_bar.setValue(100)
            self.start_btn.setEnabled(True)
            self.stop_btn.setEnabled(False)

    def update_results(self, result):
        """实时更新结果"""
        current_text = self.result_display.toPlainText()
        new_line = f"[{result['type']}] {result['target']} - 状态: {result['status']} - 发现: {result['found']}"
        self.result_display.setText(current_text + "\n" + new_line)
        self.result_display.verticalScrollBar().setValue(
            self.result_display.verticalScrollBar().maximum()
        )

    def show_custom_poc_window(self):
        """显示自定义POC窗口"""
        self.custom_poc_window = CustomPOCWindow()
        self.custom_poc_window.show()

